from PyQt6.QtWidgets import QLabel
from PyQt6.QtCore import QTimer, QPropertyAnimation, QPoint
from PyQt6.QtGui import QPixmap
class CarAnimation(QLabel):
    def __init__(self, parent, car, gate_x, gate_y, parking_x, parking_y):
        super().__init__(parent)
        self.car = car
        self.setPixmap(QPixmap("images/car.png").scaled(50, 30))  # Масштабуємо авто
        self.setScaledContents(True)
        
        self.gate_x, self.gate_y = gate_x, gate_y  # Координати воріт
        self.parking_x, self.parking_y = parking_x, parking_y  # Координати місця
        
        self.x, self.y = -100, gate_y  # Початкова позиція за межами екрану
        self.setGeometry(self.x, self.y, 50, 30)
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.move_car)
        self.timer.start(30)  # Частота оновлення анімації
        self.parent = parent
        self.cars = {}  # Збереження анімованих машин

    def animate_car(self, plate_number, spot_id):
        """Анімує в'їзд машини на паркомісце."""
        car_label = QLabel(self.parent)
        car_label.setPixmap(QPixmap("image/car.png").scaled(50, 50))  # Розмір машини
        car_label.setGeometry(50, 50, 50, 50)  # Початкове положення (зліва за екраном)

        self.cars[plate_number] = car_label
        car_label.show()

        # Анімація руху до воріт
        animation = QPropertyAnimation(car_label, b"pos")
        animation.setDuration(2000)
        animation.setEndValue(QPoint(200, 300))  # Ворота
        animation.start()
    def move_car(self):
        print(f"Поточна позиція: x={self.x}, y={self.y}")  # Дебаг

        if self.x < self.gate_x:  
            self.x += 5
        elif self.y != self.parking_y:  
            self.y += 5 if self.parking_y > self.gate_y else -5
        elif self.x != self.parking_x:  
            self.x += 5 if self.parking_x > self.gate_x else -5
        else:
            print("Машина запаркована, зупиняємо таймер")
            self.timer.stop()
            return
    
        self.move(self.x, self.y)  # Оновлюємо позицію
